public class Main {

    public static void main(String[] args){

        int myInt;

        myInt= 5;

        System.out.println("myInt: " + myInt);

        Object myObject;

        Object myObj = new Object();

        System.out.println("myObj: " + myObj);

        int[] myArr;

        myArr = new int[myInt];
        myArr[0] = 120;
        System.out.println("myArr: " + myArr);
        System.out.println("myArr.length: " + myArr.length);
        System.out.println("myArr[0]: " + myArr[0]);


    }

}
