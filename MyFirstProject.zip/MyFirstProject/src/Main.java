import java.util.Scanner;

public class Main {

    public static void main(String[] args){

        System.out.println("Hello World");

        String myName = "Drago";
        Scanner scan = new Scanner(System.in);
        System.out.print(" What is your name");
        myName = scan.next();


        System.out.print("Hello " + myName);











    }

    }
